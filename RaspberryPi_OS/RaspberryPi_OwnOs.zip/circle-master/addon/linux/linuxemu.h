#ifndef _linux_linuxemu_h
#define _linux_linuxemu_h

#ifdef __cplusplus
extern "C" {
#endif

int linuxemu_init (void);

#ifdef __cplusplus
}
#endif

#endif
