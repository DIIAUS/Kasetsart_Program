#ifndef _linux_kern_levels_h
#define _linux_kern_levels_h

#define KERN_EMERG	""
#define KERN_ALERT	""
#define KERN_CRIT	""
#define KERN_ERR	""
#define KERN_WARNING	""
#define KERN_NOTICE	""
#define KERN_INFO	""
#define KERN_DEBUG	""

#endif
