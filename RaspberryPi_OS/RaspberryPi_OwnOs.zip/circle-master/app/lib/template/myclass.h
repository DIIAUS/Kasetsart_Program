//
// myclass.h
//
#ifndef _template_myclass_h
#define _template_myclass_h

#include <circle/types.h>

class CMyClass
{
public:
	CMyClass (void);
	~CMyClass (void);

	// methods ...

private:
	// members ...
};

#endif
